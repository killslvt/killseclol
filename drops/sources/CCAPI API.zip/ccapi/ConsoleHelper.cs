﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace ccapi
{
	public static class ConsoleHelper
	{
		public static void Initialize(bool alwaysCreateNewConsole = true)
		{
			bool flag = true;
			bool flag2 = alwaysCreateNewConsole || (BaseFunctions.AttachConsole(uint.MaxValue) == 0U && (long)Marshal.GetLastWin32Error() != 5L);
			if (flag2)
			{
				flag = BaseFunctions.AllocConsole() != 0;
			}
			bool flag3 = flag;
			if (flag3)
			{
				ConsoleHelper.InitializeOutStream();
				ConsoleHelper.InitializeInStream();
			}
			Console.OutputEncoding = Encoding.UTF8;
		}

		public static void Clear()
		{
			Console.Write("\n\n");
		}

		private static void InitializeOutStream()
		{
			ConsoleHelper.fwriter = ConsoleHelper.CreateFileStream("CONOUT$", 1073741824U, 2U, FileAccess.Write);
			bool flag = ConsoleHelper.fwriter != null;
			if (flag)
			{
				ConsoleHelper.writer = new StreamWriter(ConsoleHelper.fwriter)
				{
					AutoFlush = true
				};
				Console.SetOut(ConsoleHelper.writer);
				Console.SetError(ConsoleHelper.writer);
			}
		}

		private static void InitializeInStream()
		{
			FileStream fileStream = ConsoleHelper.CreateFileStream("CONIN$", 2147483648U, 1U, FileAccess.Read);
			bool flag = fileStream != null;
			if (flag)
			{
				Console.SetIn(new StreamReader(fileStream));
			}
		}

		private static FileStream CreateFileStream(string name, uint win32DesiredAccess, uint win32ShareMode, FileAccess dotNetFileAccess)
		{
			SafeFileHandle safeFileHandle = new SafeFileHandle((IntPtr)((long)((ulong)BaseFunctions.CreateFileW(name, win32DesiredAccess, win32ShareMode, 0U, 3U, 128U, 0U))), true);
			bool flag = !safeFileHandle.IsInvalid;
			FileStream fileStream;
			if (flag)
			{
				fileStream = new FileStream(safeFileHandle, dotNetFileAccess);
			}
			else
			{
				fileStream = null;
			}
			return fileStream;
		}

		public static StreamWriter writer;

		public static FileStream fwriter;
	}
}
