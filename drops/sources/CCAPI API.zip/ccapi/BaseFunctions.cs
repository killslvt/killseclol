﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace ccapi
{
	public class BaseFunctions
	{
		public static void ExtractResource(string resourceName, string outputPath)
		{
			using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
			{
				bool flag = manifestResourceStream == null;
				if (flag)
				{
					throw new ArgumentException("Resource " + resourceName + " not found.");
				}
				using (FileStream fileStream = new FileStream(outputPath, FileMode.Create, FileAccess.Write))
				{
					manifestResourceStream.CopyTo(fileStream);
				}
			}
		}

		[DllImport("user32.dll")]
		public static extern int FindWindow(string sClass, string sWindow);

		[DllImport("user32.dll")]
		public static extern bool ShowWindow(int hWnd, int nCmdShow);

		[DllImport("user32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
		public static extern int MessageBoxA(int hWnd, string sMessage, string sCaption, uint mbType);

		[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		public static extern int MessageBoxW(int hWnd, string sMessage, string sCaption, uint mbType);

		[DllImport("kernel32.dll")]
		public static extern int GetConsoleWindow();

		[DllImport("kernel32.dll")]
		public static extern ulong OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		[DllImport("kernel32.dll")]
		public static extern bool ReadProcessMemory(ulong hProcess, ulong lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesRead);

		[DllImport("kernel32.dll")]
		public static extern bool WriteProcessMemory(ulong hProcess, ulong lpBaseAddress, byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesWritten);

		[DllImport("kernel32.dll")]
		public static extern bool VirtualProtectEx(ulong hProcess, ulong lpBaseAddress, int dwSize, uint new_protect, ref uint lpOldProtect);

		[DllImport("kernel32.dll")]
		public static extern ulong VirtualQueryEx(ulong hProcess, ulong lpAddress, out BaseFunctions.MEMORY_BASIC_INFORMATION lpBuffer, uint dwLength);

		[DllImport("kernel32.dll")]
		public static extern ulong VirtualAllocEx(ulong hProcess, ulong lpAddress, int size, uint allocation_type, uint protect);

		[DllImport("kernel32.dll")]
		public static extern ulong VirtualFreeEx(ulong hProcess, ulong lpAddress, int size, uint allocation_type);

		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern ulong GetModuleHandle(string lpModuleName);

		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern ulong GetProcAddress(ulong hModule, string procName);

		[DllImport("kernel32.dll")]
		public static extern uint GetLastError();

		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern bool CloseHandle(ulong hObject);

		[DllImport("kernel32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool GetExitCodeProcess(ulong hProcess, out uint lpExitCode);

		[DllImport("kernel32.dll")]
		public static extern int CreateRemoteThread(ulong hProcess, int lpThreadAttributes, uint dwStackSize, int lpStartAddress, int lpParameter, uint dwCreationFlags, out int lpThreadId);

		[DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
		public static extern uint GetStdHandle(uint nStdHandle);

		[DllImport("kernel32.dll")]
		public static extern void SetStdHandle(uint nStdHandle, uint handle);

		[DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int AllocConsole();

		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern bool SetConsoleTitle(string lpConsoleTitle);

		[DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
		public static extern uint AttachConsole(uint dwProcessId);

		[DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, SetLastError = true)]
		public static extern uint CreateFileW(string lpFileName, uint dwDesiredAccess, uint dwShareMode, uint lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, uint hTemplateFile);

		[DllImport("kernel32.dll")]
		public static extern uint GetCurrentProcessId();

		[DllImport("kernel32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool FreeConsole();

		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern uint CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, uint lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, uint hTemplateFile);

		public static List<BaseFunctions.ProcInfo> openProcessesByName(string processName)
		{
			List<BaseFunctions.ProcInfo> list = new List<BaseFunctions.ProcInfo>();
			Process[] processesByName = Process.GetProcessesByName(processName.Replace(".exe", ""));
			foreach (Process process in processesByName)
			{
				try
				{
					bool flag = process.Id != 0 && !process.HasExited;
					if (flag)
					{
						list.Add(new BaseFunctions.ProcInfo
						{
							processRef = process,
							baseModule = 0UL,
							handle = 0UL,
							processId = (ulong)((long)process.Id),
							processName = processName,
							windowName = ""
						});
					}
				}
				catch (NullReferenceException)
				{
				}
				catch (Exception)
				{
				}
			}
			return list;
		}

		public void flush()
		{
			foreach (ulong num in BaseFunctions.openedHandles)
			{
				BaseFunctions.CloseHandle(num);
			}
		}

		public const uint PAGE_NOACCESS = 1U;

		public const uint PAGE_READONLY = 2U;

		public const uint PAGE_READWRITE = 4U;

		public const uint PAGE_WRITECOPY = 8U;

		public const uint PAGE_EXECUTE = 16U;

		public const uint PAGE_EXECUTE_READ = 32U;

		public const uint PAGE_EXECUTE_READWRITE = 64U;

		public const uint PAGE_EXECUTE_WRITECOPY = 128U;

		public const uint PAGE_GUARD = 256U;

		public const uint PAGE_NOCACHE = 512U;

		public const uint PAGE_WRITECOMBINE = 1024U;

		public const uint MEM_COMMIT = 4096U;

		public const uint MEM_RESERVE = 8192U;

		public const uint MEM_DECOMMIT = 16384U;

		public const uint MEM_RELEASE = 32768U;

		public const uint PROCESS_WM_READ = 16U;

		public const uint PROCESS_ALL_ACCESS = 2035711U;

		private const uint GENERIC_WRITE = 1073741824U;

		private const uint GENERIC_READ = 2147483648U;

		private const uint FILE_SHARE_READ = 1U;

		private const uint FILE_SHARE_WRITE = 2U;

		private const uint OPEN_EXISTING = 3U;

		private const uint FILE_ATTRIBUTE_NORMAL = 128U;

		private const uint ERROR_ACCESS_DENIED = 5U;

		private const uint ATTACH_PARENT = 4294967295U;

		public const int EXCEPTION_CONTINUE_EXECUTION = -1;

		public const int EXCEPTION_CONTINUE_SEARCH = 0;

		public const uint STD_OUTPUT_HANDLE = 4294967285U;

		public const int MY_CODE_PAGE = 437;

		public const int SW_HIDE = 0;

		public const int SW_SHOW = 5;

		private static List<ulong> openedHandles = new List<ulong>();

		public struct MEMORY_BASIC_INFORMATION
		{
			public int BaseAddress;

			public int AllocationBase;

			public uint AllocationProtect;

			public int RegionSize;

			public uint State;

			public uint Protect;

			public uint Type;
		}

		public static class ConsoleHelper
		{
			public static void Initialize(bool alwaysCreateNewConsole = true)
			{
				bool flag = true;
				bool flag2 = alwaysCreateNewConsole || (BaseFunctions.AttachConsole(uint.MaxValue) == 0U && (long)Marshal.GetLastWin32Error() != 5L);
				if (flag2)
				{
					flag = BaseFunctions.AllocConsole() != 0;
				}
				bool flag3 = flag;
				if (flag3)
				{
					BaseFunctions.ConsoleHelper.InitializeOutStream();
					BaseFunctions.ConsoleHelper.InitializeInStream();
				}
				Console.OutputEncoding = Encoding.UTF8;
			}

			public static void Clear()
			{
				Console.Write("\n\n");
			}

			public static Process ExecuteAsAdmin(string fileName, bool showconsole, bool admin)
			{
				Process process = new Process();
				process.StartInfo.FileName = fileName;
				process.StartInfo.UseShellExecute = true;
				if (admin)
				{
					process.StartInfo.Arguments = "runas";
				}
				else
				{
					process.StartInfo.Arguments = "";
				}
				if (showconsole)
				{
					process.StartInfo.CreateNoWindow = false;
				}
				else
				{
					process.StartInfo.CreateNoWindow = true;
					process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				}
				process.Start();
				return process;
			}

			private static void InitializeOutStream()
			{
				BaseFunctions.ConsoleHelper.fwriter = BaseFunctions.ConsoleHelper.CreateFileStream("CONOUT$", 1073741824U, 2U, FileAccess.Write);
				bool flag = BaseFunctions.ConsoleHelper.fwriter != null;
				if (flag)
				{
					BaseFunctions.ConsoleHelper.writer = new StreamWriter(BaseFunctions.ConsoleHelper.fwriter)
					{
						AutoFlush = true
					};
					Console.SetOut(BaseFunctions.ConsoleHelper.writer);
					Console.SetError(BaseFunctions.ConsoleHelper.writer);
				}
			}

			private static void InitializeInStream()
			{
				FileStream fileStream = BaseFunctions.ConsoleHelper.CreateFileStream("CONIN$", 2147483648U, 1U, FileAccess.Read);
				bool flag = fileStream != null;
				if (flag)
				{
					Console.SetIn(new StreamReader(fileStream));
				}
			}

			private static FileStream CreateFileStream(string name, uint win32DesiredAccess, uint win32ShareMode, FileAccess dotNetFileAccess)
			{
				SafeFileHandle safeFileHandle = new SafeFileHandle((IntPtr)((long)((ulong)BaseFunctions.CreateFileW(name, win32DesiredAccess, win32ShareMode, 0U, 3U, 128U, 0U))), true);
				bool flag = !safeFileHandle.IsInvalid;
				FileStream fileStream;
				if (flag)
				{
					fileStream = new FileStream(safeFileHandle, dotNetFileAccess);
				}
				else
				{
					fileStream = null;
				}
				return fileStream;
			}

			public static StreamWriter writer;

			public static FileStream fwriter;
		}

		public class ProcInfo
		{
			public ProcInfo()
			{
				this.processRef = null;
				this.processId = 0UL;
				this.handle = 0UL;
			}

			public bool isOpen()
			{
				try
				{
					bool flag = this.processRef == null;
					if (flag)
					{
						return false;
					}
					bool hasExited = this.processRef.HasExited;
					if (hasExited)
					{
						return false;
					}
					bool flag2 = this.processRef.Id == 0;
					if (flag2)
					{
						return false;
					}
					bool flag3 = this.processRef.Handle == IntPtr.Zero;
					if (flag3)
					{
						return false;
					}
				}
				catch (InvalidOperationException)
				{
					return false;
				}
				catch (Exception)
				{
					return false;
				}
				bool flag4 = this.processId > 0UL;
				return flag4 && this.handle > 0UL;
			}

			public BaseFunctions.MEMORY_BASIC_INFORMATION getPage(ulong address)
			{
				BaseFunctions.MEMORY_BASIC_INFORMATION memory_BASIC_INFORMATION = default(BaseFunctions.MEMORY_BASIC_INFORMATION);
				BaseFunctions.VirtualQueryEx(this.handle, address, out memory_BASIC_INFORMATION, 28U);
				return memory_BASIC_INFORMATION;
			}

			public bool isAccessible(ulong address)
			{
				BaseFunctions.MEMORY_BASIC_INFORMATION page = this.getPage(address);
				uint protect = page.Protect;
				bool flag = page.State == 4096U;
				bool flag3;
				if (flag)
				{
					bool flag2 = protect != 4U && protect != 2U && protect != 64U;
					flag3 = !flag2 || protect == 32U;
				}
				else
				{
					flag3 = false;
				}
				return flag3;
			}

			public uint setPageProtect(ulong address, int size, uint protect)
			{
				uint num = 0U;
				BaseFunctions.VirtualProtectEx(this.handle, address, size, protect, ref num);
				return num;
			}

			public bool writeByte(ulong address, byte value)
			{
				byte[] array = new byte[] { value };
				return BaseFunctions.WriteProcessMemory(this.handle, address, array, array.Length, ref this.nothing);
			}

			public bool writeBytes(ulong address, byte[] bytes, int count = -1)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, bytes, (count == -1) ? bytes.Length : count, ref this.nothing);
			}

			public bool writeString(ulong address, string str, int count = -1)
			{
				char[] array = str.ToCharArray(0, str.Length);
				List<byte> list = new List<byte>();
				foreach (byte b in array)
				{
					list.Add(b);
				}
				return BaseFunctions.WriteProcessMemory(this.handle, address, list.ToArray(), (count == -1) ? list.Count : count, ref this.nothing);
			}

			public bool writeWString(ulong address, string str, int count = -1)
			{
				ulong num = address;
				char[] array = str.ToCharArray(0, str.Length);
				foreach (char c in array)
				{
					this.writeUInt16(num, Convert.ToUInt16(c));
					num += 2UL;
				}
				return true;
			}

			public bool writeInt16(ulong address, short value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 2, ref this.nothing);
			}

			public bool writeUInt16(ulong address, ushort value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 2, ref this.nothing);
			}

			public bool writeInt32(ulong address, int value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 4, ref this.nothing);
			}

			public bool writeUInt32(ulong address, uint value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 4, ref this.nothing);
			}

			public bool writeFloat(ulong address, float value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 4, ref this.nothing);
			}

			public bool writeDouble(ulong address, double value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 8, ref this.nothing);
			}

			public bool writeInt64(ulong address, long value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 8, ref this.nothing);
			}

			public bool writeUInt64(ulong address, ulong value)
			{
				return BaseFunctions.WriteProcessMemory(this.handle, address, BitConverter.GetBytes(value), 8, ref this.nothing);
			}

			public byte readByte(ulong address)
			{
				byte[] array = new byte[1];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 1, ref this.nothing);
				return array[0];
			}

			public byte[] readBytes(ulong address, int count)
			{
				byte[] array = new byte[count];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, count, ref this.nothing);
				return array;
			}

			public string readString(ulong address, int count = -1)
			{
				string text = "";
				ulong num = address;
				bool flag = count == -1;
				if (flag)
				{
					while (num != 512UL)
					{
						byte[] array = this.readBytes(num, 512);
						int i = 0;
						while (i < array.Length)
						{
							byte b = array[i];
							switch (b)
							{
							case 9:
							case 10:
							case 13:
							case 32:
							case 33:
							case 34:
							case 35:
							case 36:
							case 37:
							case 38:
							case 39:
							case 40:
							case 41:
							case 42:
							case 43:
							case 44:
							case 45:
							case 46:
							case 47:
							case 48:
							case 49:
							case 50:
							case 51:
							case 52:
							case 53:
							case 54:
							case 55:
							case 56:
							case 57:
							case 58:
							case 59:
							case 60:
							case 61:
							case 62:
							case 63:
							case 64:
							case 65:
							case 66:
							case 67:
							case 68:
							case 69:
							case 70:
							case 71:
							case 72:
							case 73:
							case 74:
							case 75:
							case 76:
							case 77:
							case 78:
							case 79:
							case 80:
							case 81:
							case 82:
							case 83:
							case 84:
							case 85:
							case 86:
							case 87:
							case 88:
							case 89:
							case 90:
							case 91:
							case 92:
							case 93:
							case 94:
							case 95:
							case 96:
							case 97:
							case 98:
							case 99:
							case 100:
							case 101:
							case 102:
							case 103:
							case 104:
							case 105:
							case 106:
							case 107:
							case 108:
							case 109:
							case 110:
							case 111:
							case 112:
							case 113:
							case 114:
							case 115:
							case 116:
							case 117:
							case 118:
							case 119:
							case 120:
							case 121:
							case 122:
							case 123:
							case 124:
							case 125:
							case 126:
							case 127:
							{
								string text2 = text;
								char c = (char)b;
								text = text2 + c.ToString();
								i++;
								continue;
							}
							}
							num = 0UL;
							break;
						}
						num += 512UL;
					}
				}
				else
				{
					byte[] array2 = this.readBytes(num, count);
					foreach (byte b2 in array2)
					{
						string text3 = text;
						char c2 = (char)b2;
						text = text3 + c2.ToString();
					}
				}
				return text;
			}

			public string readWString(ulong address, int count = -1)
			{
				string text = "";
				ulong num = address;
				bool flag = count == -1;
				if (flag)
				{
					while (num != 512UL)
					{
						byte[] array = this.readBytes(num, 512);
						for (int i = 0; i < array.Length; i += 2)
						{
							bool flag2 = array[i] == 0 && array[i + 1] == 0;
							if (flag2)
							{
								num = 0UL;
								break;
							}
							text += Encoding.Unicode.GetString(new byte[]
							{
								array[i],
								array[i + 1]
							}, 0, 2);
						}
						num += 512UL;
					}
				}
				else
				{
					byte[] array2 = this.readBytes(num, count * 2);
					for (int j = 0; j < array2.Length; j += 2)
					{
						text += Encoding.Unicode.GetString(new byte[]
						{
							array2[j],
							array2[j + 1]
						}, 0, 2);
					}
				}
				return text;
			}

			public short readInt16(ulong address)
			{
				byte[] array = new byte[2];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 2, ref this.nothing);
				return BitConverter.ToInt16(array, 0);
			}

			public ushort readUInt16(ulong address)
			{
				byte[] array = new byte[2];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 2, ref this.nothing);
				return BitConverter.ToUInt16(array, 0);
			}

			public int readInt32(ulong address)
			{
				byte[] array = new byte[4];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 4, ref this.nothing);
				return BitConverter.ToInt32(array, 0);
			}

			public uint readUInt32(ulong address)
			{
				byte[] array = new byte[4];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 4, ref this.nothing);
				return BitConverter.ToUInt32(array, 0);
			}

			public float readFloat(ulong address)
			{
				byte[] array = new byte[4];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 4, ref this.nothing);
				return BitConverter.ToSingle(array, 0);
			}

			public double readDouble(ulong address)
			{
				byte[] array = new byte[8];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 8, ref this.nothing);
				return BitConverter.ToDouble(array, 0);
			}

			public long readInt64(ulong address)
			{
				byte[] array = new byte[8];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 8, ref this.nothing);
				return BitConverter.ToInt64(array, 0);
			}

			public ulong readUInt64(ulong address)
			{
				byte[] array = new byte[8];
				BaseFunctions.ReadProcessMemory(this.handle, address, array, 8, ref this.nothing);
				return BitConverter.ToUInt64(array, 0);
			}

			public bool isPrologue(ulong address)
			{
				byte[] array = this.readBytes(address, 3);
				bool flag = array[0] == 139 && array[1] == byte.MaxValue && array[2] == 85;
				bool flag2;
				if (flag)
				{
					flag2 = true;
				}
				else
				{
					bool flag3 = address % 16UL > 0UL;
					if (flag3)
					{
						flag2 = false;
					}
					else
					{
						bool flag4 = (array[0] == 82 && array[1] == 139 && array[2] == 212) || (array[0] == 83 && array[1] == 139 && array[2] == 220) || (array[0] == 85 && array[1] == 139 && array[2] == 236) || (array[0] == 86 && array[1] == 139 && array[2] == 244) || (array[0] == 87 && array[1] == 139 && array[2] == byte.MaxValue);
						flag2 = flag4;
					}
				}
				return flag2;
			}

			public bool isEpilogue(ulong address)
			{
				byte b = this.readByte(address);
				byte b2 = b;
				byte b3 = b2;
				if (b3 - 194 > 1)
				{
					if (b3 == 201)
					{
						return true;
					}
					if (b3 != 204)
					{
						goto IL_0094;
					}
				}
				byte b4 = this.readByte(address - 1UL);
				bool flag = b4 - 90 > 1 && b4 - 93 > 2;
				if (!flag)
				{
					bool flag2 = b == 194;
					if (flag2)
					{
						ushort num = this.readUInt16(address + 1UL);
						bool flag3 = num % 4 == 0 && num > 0;
						if (flag3)
						{
							return true;
						}
					}
					return true;
				}
				IL_0094:
				return false;
			}

			private bool isValidCode(ulong address)
			{
				bool flag = this.readUInt64(address) == 0UL;
				return !flag || this.readUInt64(address + 8UL) > 0UL;
			}

			public ulong gotoPrologue(ulong address)
			{
				ulong num = address;
				bool flag = this.isPrologue(num);
				ulong num2;
				if (flag)
				{
					num2 = num;
				}
				else
				{
					while (!this.isPrologue(num) && this.isValidCode(address))
					{
						num = ((num % 16UL == 0UL) ? (num - 16UL) : (num - num % 16UL));
					}
					num2 = num;
				}
				return num2;
			}

			public ulong gotoNextPrologue(ulong address)
			{
				ulong num = address;
				bool flag = this.isPrologue(num);
				if (flag)
				{
					num += 16UL;
				}
				while (!this.isPrologue(num) && this.isValidCode(num))
				{
					num = ((num % 16UL != 0UL) ? (num + num % 16UL) : (num + 16UL));
				}
				return num;
			}

			public Process processRef;

			public ulong processId;

			public string processName;

			public string windowName;

			public ulong handle;

			public ulong baseModule;

			private int nothing;
		}
	}
}
