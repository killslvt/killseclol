﻿using System;

namespace ccapi
{
	public enum InjectionStatus
	{
		FAILED,
		FAILED_ADMINISTRATOR_ACCESS,
		ALREADY_INJECTING,
		ALREADY_INJECTED,
		SUCCESS
	}
}
