﻿using System;
using System.Net;

namespace ccapi
{
	public class QuickScript
	{
		public static void InfiniteYield()
		{
			ExploitApi.Execute(new WebClient().DownloadString("https://raw.githubusercontent.com/s-y-n-q/ccapi/main/QuickScript/InfiniteYield.lua"));
		}

		public static void SetWalkSpeed(int speed)
		{
			ExploitApi.Execute("game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = " + speed.ToString());
		}

		public static void SetJumpPower(int power)
		{
			ExploitApi.Execute("game.Players.LocalPlayer.Character.Humanoid.JumpPower = " + power.ToString());
		}
	}
}
