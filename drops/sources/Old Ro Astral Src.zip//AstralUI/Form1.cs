using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;
using AstralUI.Properties;
using LunarAPI;
using Microsoft.Win32;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Suite;

namespace AstralUI;

public class Form1 : Form
{
	private Injector injector = new Injector();

	private WebClient wc = new WebClient();

	private string defPath = Application.StartupPath + "//Monaco//";

	private IContainer components = null;

	private SiticoneElipse siticoneElipse1;

	private SiticoneElipse siticoneElipse2;

	private PictureBox pictureBox1;

	private WebBrowser webBrowser1;

	private SiticoneDragControl siticoneDragControl1;

	private SiticoneButton siticoneButton1;

	private SiticoneElipse siticoneElipse3;

	private SiticoneElipse siticoneElipse4;

	private SiticoneButton siticoneButton2;

	private SiticoneButton siticoneButton3;

	private SiticoneButton siticoneButton4;

	private SiticoneButton siticoneButton5;

	private void addIntel(string label, string kind, string detail, string insertText)
	{
		string text = "\"" + label + "\"";
		string text2 = "\"" + kind + "\"";
		string text3 = "\"" + detail + "\"";
		string text4 = "\"" + insertText + "\"";
		webBrowser1.Document.InvokeScript("AddIntellisense", new object[4] { label, kind, detail, insertText });
	}

	private void addGlobalF()
	{
		string[] array = File.ReadAllLines(defPath + "//globalf.txt");
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (Enumerable.Contains(text, ':'))
			{
				addIntel(text, "Function", text, text.Substring(1));
			}
			else
			{
				addIntel(text, "Function", text, text);
			}
		}
	}

	private void addGlobalV()
	{
		foreach (string item in File.ReadLines(defPath + "//globalv.txt"))
		{
			addIntel(item, "Variable", item, item);
		}
	}

	private void addGlobalNS()
	{
		foreach (string item in File.ReadLines(defPath + "//globalns.txt"))
		{
			addIntel(item, "Class", item, item);
		}
	}

	private void addMath()
	{
		foreach (string item in File.ReadLines(defPath + "//classfunc.txt"))
		{
			addIntel(item, "Method", item, item);
		}
	}

	private void addBase()
	{
		foreach (string item in File.ReadLines(defPath + "//base.txt"))
		{
			addIntel(item, "Keyword", item, item);
		}
	}

	public Form1()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
	}

	private async void Form1_Load(object sender, EventArgs e)
	{
		WebClient wc = new WebClient
		{
			Proxy = null
		};
		try
		{
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", writable: true);
			string friendlyName = AppDomain.CurrentDomain.FriendlyName;
			if (registryKey.GetValue(friendlyName) == null)
			{
				registryKey.SetValue(friendlyName, 11001, RegistryValueKind.DWord);
			}
		}
		catch (Exception)
		{
		}
		webBrowser1.Url = new Uri($"file:///{Directory.GetCurrentDirectory()}/Monaco/Monaco.html");
		await Task.Delay(500);
		HtmlDocument document = webBrowser1.Document;
		object[] array = new string[1] { "Dark" };
		document.InvokeScript("SetTheme", array);
		addBase();
		addMath();
		addGlobalNS();
		addGlobalV();
		addGlobalF();
		webBrowser1.Document.InvokeScript("SetText", new object[1] { "-- Powered By LunarAPI --" });
	}

	private void siticoneButton2_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	private void siticoneButton3_Click(object sender, EventArgs e)
	{
		((Form)this).WindowState = (FormWindowState)1;
	}

	private void siticoneButton5_Click(object sender, EventArgs e)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Invalid comparison between Unknown and I4
		OpenFileDialog val = new OpenFileDialog();
		val.Multiselect = true;
		((FileDialog)val).Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
		if ((int)((CommonDialog)val).ShowDialog() == 1)
		{
			string[] fileNames = ((FileDialog)val).FileNames;
			foreach (string path in fileNames)
			{
				string text = File.ReadAllText(path);
				webBrowser1.Document.InvokeScript("SetText", new object[1] { text });
			}
		}
	}

	private async void siticoneButton1_Click(object sender, EventArgs e)
	{
		await injector.Inject();
	}

	private async void siticoneButton4_Click(object sender, EventArgs e)
	{
		HtmlDocument document = webBrowser1.Document;
		string scriptName = "GetText";
		object[] array = new string[0];
		object[] args = array;
		object obj = document.InvokeScript(scriptName, args);
		string script = obj.ToString();
		await injector.ExecuteScript(script);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected O, but got Unknown
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Expected O, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Expected O, but got Unknown
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Expected O, but got Unknown
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Expected O, but got Unknown
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Expected O, but got Unknown
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Expected O, but got Unknown
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Expected O, but got Unknown
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Expected O, but got Unknown
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Expected O, but got Unknown
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Expected O, but got Unknown
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Expected O, but got Unknown
		//IL_0562: Unknown result type (might be due to invalid IL or missing references)
		//IL_056c: Expected O, but got Unknown
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Expected O, but got Unknown
		//IL_08ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d8: Expected O, but got Unknown
		components = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Form1));
		siticoneElipse1 = new SiticoneElipse(components);
		siticoneElipse2 = new SiticoneElipse(components);
		webBrowser1 = new WebBrowser();
		siticoneDragControl1 = new SiticoneDragControl(components);
		siticoneElipse3 = new SiticoneElipse(components);
		siticoneElipse4 = new SiticoneElipse(components);
		siticoneButton5 = new SiticoneButton();
		siticoneButton4 = new SiticoneButton();
		siticoneButton3 = new SiticoneButton();
		siticoneButton2 = new SiticoneButton();
		siticoneButton1 = new SiticoneButton();
		pictureBox1 = new PictureBox();
		((ISupportInitialize)pictureBox1).BeginInit();
		((Control)this).SuspendLayout();
		siticoneElipse2.BorderRadius = 10;
		siticoneElipse2.TargetControl = (Control)(object)this;
		((Control)webBrowser1).Location = new Point(16, 69);
		((Control)webBrowser1).MinimumSize = new Size(20, 20);
		((Control)webBrowser1).Name = "webBrowser1";
		((Control)webBrowser1).Size = new Size(708, 279);
		((Control)webBrowser1).TabIndex = 1;
		siticoneDragControl1.TargetControl = (Control)(object)this;
		siticoneElipse3.TargetControl = (Control)(object)siticoneButton1;
		siticoneElipse4.TargetControl = (Control)(object)webBrowser1;
		siticoneButton5.CheckedState.Parent = (CustomButtonBase)(object)siticoneButton5;
		siticoneButton5.CustomImages.Parent = (CustomButtonBase)(object)siticoneButton5;
		siticoneButton5.FillColor = Color.FromArgb(15, 15, 15);
		((Control)siticoneButton5).Font = new Font("Segoe UI", 9f);
		((Control)siticoneButton5).ForeColor = Color.White;
		siticoneButton5.HoveredState.FillColor = Color.FromArgb(16, 16, 16);
		siticoneButton5.HoveredState.Parent = (CustomButtonBase)(object)siticoneButton5;
		siticoneButton5.Image = (Image)(object)Resources.icons8_open_file_50;
		((Control)siticoneButton5).Location = new Point(52, 352);
		((Control)siticoneButton5).Name = "siticoneButton5";
		siticoneButton5.ShadowDecoration.Parent = (Control)(object)siticoneButton5;
		((Control)siticoneButton5).Size = new Size(43, 38);
		((Control)siticoneButton5).TabIndex = 6;
		((Control)siticoneButton5).Click += siticoneButton5_Click;
		siticoneButton4.CheckedState.Parent = (CustomButtonBase)(object)siticoneButton4;
		siticoneButton4.CustomImages.Parent = (CustomButtonBase)(object)siticoneButton4;
		siticoneButton4.FillColor = Color.FromArgb(15, 15, 15);
		((Control)siticoneButton4).Font = new Font("Segoe UI", 9f);
		((Control)siticoneButton4).ForeColor = Color.White;
		siticoneButton4.HoveredState.FillColor = Color.FromArgb(16, 16, 16);
		siticoneButton4.HoveredState.Parent = (CustomButtonBase)(object)siticoneButton4;
		siticoneButton4.Image = (Image)(object)Resources.icons8_play_30;
		((Control)siticoneButton4).Location = new Point(16, 353);
		((Control)siticoneButton4).Name = "siticoneButton4";
		siticoneButton4.ShadowDecoration.Parent = (Control)(object)siticoneButton4;
		((Control)siticoneButton4).Size = new Size(43, 38);
		((Control)siticoneButton4).TabIndex = 5;
		((Control)siticoneButton4).Click += siticoneButton4_Click;
		siticoneButton3.CheckedState.Parent = (CustomButtonBase)(object)siticoneButton3;
		siticoneButton3.CustomImages.Parent = (CustomButtonBase)(object)siticoneButton3;
		siticoneButton3.FillColor = Color.FromArgb(15, 15, 15);
		((Control)siticoneButton3).Font = new Font("Segoe UI", 9f);
		((Control)siticoneButton3).ForeColor = Color.White;
		siticoneButton3.HoveredState.FillColor = Color.FromArgb(16, 16, 16);
		siticoneButton3.HoveredState.Parent = (CustomButtonBase)(object)siticoneButton3;
		siticoneButton3.Image = (Image)(object)Resources.icons8_minimize_50;
		((Control)siticoneButton3).Location = new Point(650, 12);
		((Control)siticoneButton3).Name = "siticoneButton3";
		siticoneButton3.ShadowDecoration.Parent = (Control)(object)siticoneButton3;
		((Control)siticoneButton3).Size = new Size(34, 32);
		((Control)siticoneButton3).TabIndex = 4;
		((Control)siticoneButton3).Click += siticoneButton3_Click;
		siticoneButton2.CheckedState.Parent = (CustomButtonBase)(object)siticoneButton2;
		siticoneButton2.CustomImages.Parent = (CustomButtonBase)(object)siticoneButton2;
		siticoneButton2.FillColor = Color.FromArgb(15, 15, 15);
		((Control)siticoneButton2).Font = new Font("Segoe UI", 9f);
		((Control)siticoneButton2).ForeColor = Color.White;
		siticoneButton2.HoveredState.FillColor = Color.FromArgb(16, 16, 16);
		siticoneButton2.HoveredState.Parent = (CustomButtonBase)(object)siticoneButton2;
		siticoneButton2.Image = (Image)(object)Resources.icons8_x_32;
		((Control)siticoneButton2).Location = new Point(690, 12);
		((Control)siticoneButton2).Name = "siticoneButton2";
		siticoneButton2.ShadowDecoration.Parent = (Control)(object)siticoneButton2;
		((Control)siticoneButton2).Size = new Size(34, 32);
		((Control)siticoneButton2).TabIndex = 3;
		((Control)siticoneButton2).Click += siticoneButton2_Click;
		siticoneButton1.CheckedState.Parent = (CustomButtonBase)(object)siticoneButton1;
		siticoneButton1.CustomImages.Parent = (CustomButtonBase)(object)siticoneButton1;
		siticoneButton1.FillColor = Color.FromArgb(15, 15, 15);
		((Control)siticoneButton1).Font = new Font("Segoe UI", 9f);
		((Control)siticoneButton1).ForeColor = Color.White;
		siticoneButton1.HoveredState.FillColor = Color.FromArgb(16, 16, 16);
		siticoneButton1.HoveredState.Parent = (CustomButtonBase)(object)siticoneButton1;
		siticoneButton1.Image = (Image)(object)Resources.icons8_inject_64;
		siticoneButton1.ImageSize = new Size(30, 30);
		((Control)siticoneButton1).Location = new Point(681, 352);
		((Control)siticoneButton1).Name = "siticoneButton1";
		siticoneButton1.ShadowDecoration.Parent = (Control)(object)siticoneButton1;
		((Control)siticoneButton1).Size = new Size(43, 38);
		((Control)siticoneButton1).TabIndex = 2;
		((Control)siticoneButton1).Click += siticoneButton1_Click;
		pictureBox1.Image = (Image)(object)Resources.Untitled__9__removebg_preview;
		((Control)pictureBox1).Location = new Point(12, 12);
		((Control)pictureBox1).Name = "pictureBox1";
		((Control)pictureBox1).Size = new Size(72, 48);
		pictureBox1.SizeMode = (PictureBoxSizeMode)1;
		pictureBox1.TabIndex = 0;
		pictureBox1.TabStop = false;
		((ContainerControl)this).AutoScaleDimensions = new SizeF(6f, 13f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Control)this).BackColor = Color.FromArgb(15, 15, 15);
		((Form)this).ClientSize = new Size(737, 395);
		((Control)this).Controls.Add((Control)(object)siticoneButton5);
		((Control)this).Controls.Add((Control)(object)siticoneButton4);
		((Control)this).Controls.Add((Control)(object)siticoneButton3);
		((Control)this).Controls.Add((Control)(object)siticoneButton2);
		((Control)this).Controls.Add((Control)(object)siticoneButton1);
		((Control)this).Controls.Add((Control)(object)webBrowser1);
		((Control)this).Controls.Add((Control)(object)pictureBox1);
		((Form)this).FormBorderStyle = (FormBorderStyle)0;
		((Form)this).Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
		((Control)this).Name = "Form1";
		((Form)this).StartPosition = (FormStartPosition)1;
		((Control)this).Text = "Astral";
		((Form)this).Load += Form1_Load;
		((ISupportInitialize)pictureBox1).EndInit();
		((Control)this).ResumeLayout(false);
	}
}
