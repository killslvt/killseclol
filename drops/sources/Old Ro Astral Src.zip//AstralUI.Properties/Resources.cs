using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace AstralUI.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				ResourceManager resourceManager = new ResourceManager("AstralUI.Properties.Resources", typeof(Resources).Assembly);
				resourceMan = resourceManager;
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static Bitmap icons8_inject_64
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-inject-64", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap icons8_minimize_16
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-minimize-16", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap icons8_minimize_50
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-minimize-50", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap icons8_open_file_50
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-open-file-50", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap icons8_play_30
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-play-30", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap icons8_x_32
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("icons8-x-32", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal static Bitmap Untitled__9__removebg_preview
	{
		get
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Expected O, but got Unknown
			object @object = ResourceManager.GetObject("Untitled__9_-removebg-preview", resourceCulture);
			return (Bitmap)@object;
		}
	}

	internal Resources()
	{
	}
}
